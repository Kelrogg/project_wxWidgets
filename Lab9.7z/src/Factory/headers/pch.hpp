#ifndef PCH_HPP
#define PCH_HPP

#include <iostream>
#include <vector>
#include <stdexcept>
#include <utility>
#include <cmath>
#include <sstream>
#include <string>
#include <memory>
//#include <wx/dcsvg.h>

#endif
