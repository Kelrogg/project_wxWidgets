#ifndef COMMAND_DOCUMENT_ELEMENTS_IELEMENT_H_
#define COMMAND_DOCUMENT_ELEMENTS_IELEMENT_H_

#include "IElement_fwd.hpp"

class IElement
{
public:
	virtual ~IElement() = default;
};

#endif
