#ifndef PCH_HPP
#define PCH_HPP

constexpr auto IMG_PDF_NAME = "panda_bambuk.pdf";
constexpr auto IMG_JPG_SRC = "panda_bambuk.jpg";

#include <boost/test/unit_test.hpp>

#endif
