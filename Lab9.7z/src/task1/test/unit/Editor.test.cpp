#include "pch.hpp"

#include "Editor/Editor.hpp"

BOOST_AUTO_TEST_SUITE(Editor_tests)

	BOOST_AUTO_TEST_CASE(Create_editor_tests)
	{
	}

BOOST_AUTO_TEST_SUITE_END();
